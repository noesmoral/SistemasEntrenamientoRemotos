public class VistaVehiculo1{ 
    protected String descripcion; 
 
    public VistaVehiculo1(String descripcion){ 
        this.descripcion = descripcion; 
    } 
    public void dibuja(){ 
        System.out.print(descripcion); 
    } 
}