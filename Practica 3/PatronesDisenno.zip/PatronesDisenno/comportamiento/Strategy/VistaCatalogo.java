import java.util.*; 

public class VistaCatalogo{ 
    protected List<VistaVehiculo1> contenido = new ArrayList<VistaVehiculo1>(); 
    protected DibujaCatalogo dibujo; 
 
    public VistaCatalogo(DibujaCatalogo dibujo){ 
       contenido.add(new VistaVehiculo1("vehiculo economico")); 
       contenido.add(new VistaVehiculo1("vehiculo especial")); 
       contenido.add(new VistaVehiculo1("vehiculo rapido")); 
       contenido.add(new VistaVehiculo1("vehiculo confortable"));
       contenido.add(new VistaVehiculo1("vehiculo deportivo")); 
       this.dibujo = dibujo; 
    } 
 
    public void dibuja(){ 
        dibujo.dibuja(contenido); 
    } 
}