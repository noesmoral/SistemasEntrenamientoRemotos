public class Usuario5{ 
    public static void main(String[] args){ 
	// crear una representación gráfica de cada tipo 
        VistaCatalogo vistaCatalogo1 = new VistaCatalogo(new DibujaUnVehiculoPorLinea()); 
        vistaCatalogo1.dibuja(); 
        VistaCatalogo vistaCatalogo2 = new VistaCatalogo(new DibujaTresVehiculosPorLinea()); 
        vistaCatalogo2.dibuja(); 
    } 
}