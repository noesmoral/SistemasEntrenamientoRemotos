import java.util.*;

public class DibujaTresVehiculosPorLinea implements DibujaCatalogo{ 
    public void dibuja(List<VistaVehiculo1> contenido) 
    { 
        int contador; 
        System.out.println("Dibuja los vehiculos mostrando tres vehiculos por linea"); 
        contador = 0; 
        for (VistaVehiculo1 vistaVehiculo: contenido){ 
            vistaVehiculo.dibuja(); 
            contador++; 
            if (contador == 3){ 
                System.out.println(); 
                contador = 0; 
            } 
            else 
                System.out.print(" "); 
        } 
        if (contador != 0) 
            System.out.println(); 
        System.out.println(); 
    } 
}