import java.util.*; 

public class DibujaUnVehiculoPorLinea implements DibujaCatalogo{ 
     public void dibuja(List<VistaVehiculo1> contenido){ 
        System.out.println("Dibuja los vehiculos mostrando un vehiculo por linea"); 
        for (VistaVehiculo1 vistaVehiculo: contenido){ 
            vistaVehiculo.dibuja(); 
            System.out.println(); 
        } 
        System.out.println(); 
    } 
}
