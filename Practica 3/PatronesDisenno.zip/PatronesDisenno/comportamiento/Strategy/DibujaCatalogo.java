import java.util.*; 

public interface DibujaCatalogo{ 
    void dibuja(List<VistaVehiculo1> contenido); 
}