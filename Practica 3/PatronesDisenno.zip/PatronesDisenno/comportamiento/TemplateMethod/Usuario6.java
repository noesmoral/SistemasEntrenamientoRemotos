public class Usuario6{ 
    public static void main(String[] args){ 
	    // crear un pedido de cada uno de los dos países considerados
        Pedido1 pedidoEspanna = new PedidoEspanna(); 
        pedidoEspanna.setImporteSinIVA(10000); 
        pedidoEspanna.calculaPrecioConIVA(); 
        pedidoEspanna.visualiza(); 
 
        Pedido1 pedidoBelgica = new PedidoBelgica(); 
        pedidoBelgica.setImporteSinIVA(10000); 
        pedidoBelgica.calculaPrecioConIVA(); 
        pedidoBelgica.visualiza(); 
    } 
}