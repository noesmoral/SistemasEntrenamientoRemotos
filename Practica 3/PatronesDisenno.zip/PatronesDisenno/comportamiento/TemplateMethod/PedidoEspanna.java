public class PedidoEspanna extends Pedido1{ 
    protected void calculaIVA(){ 
        importeIVA = importeSinIVA * 0.21; 
    } 
}