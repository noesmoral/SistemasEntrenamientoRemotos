public class PedidoBelgica extends Pedido1{ 
    protected void calculaIVA(){ 
        importeIVA = importeSinIVA * 0.15; 
    } 
}