public class Usuario4{
    public static void main(String[] args){
       Vehiculo vehiculo = new Vehiculo();
       vehiculo.setDescripcion("Vehiculo economico");
       vehiculo.setPrecio(5000.0);
       VistaVehiculo vistaVehiculo = new VistaVehiculo(vehiculo);
       vistaVehiculo.redibuja();
       vehiculo.setPrecio(4500.0);
       //¿HAce falta mas para refrescar las vistas creadas?
       VistaVehiculo vistaVehiculo2 = new VistaVehiculo(vehiculo);
    }
}
