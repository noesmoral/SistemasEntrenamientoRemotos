public interface Observador{ 
    void actualiza();
}
