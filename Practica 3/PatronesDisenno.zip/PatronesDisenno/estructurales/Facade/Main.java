public class Main {

    public static void main(String[] args) {
        // TODO code application logic here
        WebServiceAuto servicioWeb = new WebServiceAutoImpl();
        
        System.out.println(servicioWeb.buscaVehiculos(5500, 8500));
        System.out.println(servicioWeb.documento(2));
    }
    
}
