public interface GestionDocumento{ 
  String documento(int indice); 
} 