import java.util.*; 

public interface Catalogo2{ 
    List<String> buscaVehiculos(int precioMin, int precioMax); 
}