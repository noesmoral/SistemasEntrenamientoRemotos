public class Usuario2{
    public static void main(String[] args) {
       //el cliente crea una empresa madre que posee un vehículo y dos filiales. La primera filial posee un vehículo, y la segunda posee dos filiares a su vez //
        Empresa empresa3 = new EmpresaSinFilial();
        Empresa empresa4 = new EmpresaSinFilial();
        Empresa empresa1 = new EmpresaSinFilial();
        empresa1.agregaVehiculo();
        Empresa empresa2 = new EmpresaMadre();
        empresa2.agregaFilial(empresa3);
        empresa2.agregaFilial(empresa4);
        Empresa grupo = new EmpresaMadre();
        empresa2.agregaFilial(empresa1);
        grupo.agregaFilial(empresa2);
        grupo.agregaVehiculo();
        System.out.println("Coste de mantenimiento total del grupo: "+grupo.calculaCosteMantenimiento());
    }
}
