public class DocumentoPdf implements Documento{ 
    
  protected ComponentePdf herramientaPdf = new ComponentePdf();
  
  public void setContenido(String contenido){
    this.herramientaPdf.pdfFijaContenido(contenido);
  }
  
  public void dibuja(){
    this.herramientaPdf.pdfPreparaVisualizacion();
    this.herramientaPdf.pdfRefresca();
    this.herramientaPdf.pdfFinalizaVisualizacion();
  }
  
  public void imprime(){
    this.herramientaPdf.pdfEnviaImpresora();
  }
}
