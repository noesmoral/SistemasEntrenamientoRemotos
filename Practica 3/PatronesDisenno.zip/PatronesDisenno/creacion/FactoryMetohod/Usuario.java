public class Usuario{ 
    public static void main(String[] args) { 
	// crear un Cliente que paga al contado con dos pedidos de 2000 y 10000, respectivamente, y otro cliente que utiliza crédito con dos pedidos: de 2000 y 10000 también //
        Cliente clienteContado=new ClienteContado();
        Cliente clienteCredito=new ClienteCredito(); 
        //completa código
        clienteContado.nuevoPedido(2000);
        clienteContado.nuevoPedido(1000);
        clienteCredito.nuevoPedido(2000);
        clienteCredito.nuevoPedido(1000); 
    } 
}