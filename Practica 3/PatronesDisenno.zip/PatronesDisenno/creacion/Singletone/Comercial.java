public class Comercial {
    private String nombre;
    private String direccion;
    private String email;
    private static Comercial elComercial = null;

    private Comercial(){
    }

    public static Comercial instance() {
        if(elComercial == null){
            elComercial = new Comercial();
        }
        return elComercial;
    }

    public void visualiza(){
        System.out.println("Nombre: "+ nombre);
        System.out.println("Direccion: "+ direccion);
        System.out.println("Email: "+ email);
    }
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public String getDireccion(){
        return direccion;
    }
    public void setDireccion(String direccion){
        this.direccion = direccion;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }
}
