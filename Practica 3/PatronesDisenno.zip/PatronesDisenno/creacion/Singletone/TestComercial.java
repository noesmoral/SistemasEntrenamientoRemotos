public class TestComercial{
    public static void main(String[] args){
        //completar
        Comercial elComercial = Comercial.instance();

        elComercial.setNombre("Comercial Auto");
        elComercial.setDireccion("Madrid");
        elComercial.setEmail("comercial@comerciales.com");
        //System.out.println(elComercial.getEmail());
        //muestra el comercial del sistema
        visualiza();
    }

    public static void visualiza(){
        Comercial elComercial = Comercial.instance();
        elComercial.visualiza();
    }
}
