import java.util.*;

public class DocumentacionCliente extends Documentacion{
    
    public DocumentacionCliente(String informacion){
        documentos = new ArrayList<Documento2>();
        DocumentacionEnBlanco documentacionEnBlanco = DocumentacionEnBlanco.Instance();
        List<Documento2> documentosEnBlanco = documentacionEnBlanco.getDocumentos();
        for (Documento2 documento: documentosEnBlanco){
            Documento2 copiaDocumento = documento.duplica();
            copiaDocumento.rellena(informacion);
            documentos.add(copiaDocumento);
        }
    }
    public void visualiza(){
        for (Documento2 documento: documentos)
            documento.visualiza();
        }
    public void imprime(){
        for (Documento2 documento: documentos)
            documento.imprime();
    }
}
