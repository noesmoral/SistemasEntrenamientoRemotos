public class Usuario3
{
    public static void main(String[] args){
        //inicializacion de la documentacion en blanco
        DocumentacionEnBlanco documentacionEnBlanco = DocumentacionEnBlanco.Instance();
        documentacionEnBlanco.incluye(new CertificadoCesion());
        documentacionEnBlanco.incluye(new SolicitudMatriculacion());
        // creacion de documentacion nueva para dos clientes
        DocumentacionCliente documentacionCliente1 = new DocumentacionCliente("Cliente1");
        DocumentacionCliente documentacionCliente2 = new DocumentacionCliente("Cliente2");
        //completa código
        documentacionCliente1.visualiza();
        documentacionCliente2.visualiza();
    }
}
