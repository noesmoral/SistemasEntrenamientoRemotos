import java.util.*;

public abstract class Documentacion{
    
  protected List<Documento2> documentos;
  
  public List<Documento2> getDocumentos(){
    return this.documentos;
  }
}
