public abstract class Documento2 implements Cloneable{
    
    protected String contenido = new String();
    
    public Documento2 duplica(){
        Documento2 resultado;
        try{
            resultado = (Documento2)this.clone();
        }
        catch (CloneNotSupportedException exception){
            return null;
        }
        return resultado;
    }
    
    public void rellena(String informacion){
        contenido = informacion;
    }
    
    public abstract void imprime();
    public abstract void visualiza();
}
