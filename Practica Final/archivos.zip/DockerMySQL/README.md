docker build -t mysqldb .
docker run -d -p 3306:3306 --name mysqlserv mysqldb