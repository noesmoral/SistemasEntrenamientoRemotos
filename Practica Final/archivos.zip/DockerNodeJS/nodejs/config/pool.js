var mysql     =    require('mysql');

var pool      =    mysql.createPool({
    connectionLimit : 10, //important
    host     : 'mysqlserv',
    user     : 'admin',
    password : 'admin',
    database : 'MySQLNode',
    debug    :  false
});

exports.pool = pool;
