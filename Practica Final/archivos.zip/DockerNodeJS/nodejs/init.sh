#!/bin/bash

cd nodejs
npm install npm -g
npm cache clean -f
npm install -g n
n stable
node -v
npm install nodemon -g
npm install
nodemon --watch api --watch app app.js
