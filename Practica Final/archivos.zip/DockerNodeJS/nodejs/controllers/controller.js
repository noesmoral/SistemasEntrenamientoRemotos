(function() {
    var app = angular.module('pruebaAngular',['tabCtrl']);

    app.controller('alumnosController', function($scope, $http){
        $scope.getAlumnos = function(){
            $http.get('/getAlumnos').then(function(data){
                $scope.alumnos = data.data;
            });
        };
        $scope.getAlumnos();

        $scope.toggleCreacion = function(){
            if($scope.creacion){
                $scope.creacion = false;
            }else{
                $scope.creacion = true;
            }
        };

        $scope.crearAlumno = function(){

            alumno = {Nombre: $scope.nombreIn,  Apellidos: $scope.apellidosIn, Sexo: $scope.sexSelect}

            $http.post('/createAlumno', {alumno: alumno} ).then(function(){
                $scope.$evalAsync(function(){
                    $scope.getAlumnos();
                    $scope.creacion = false;
                    $scope.nombreIn = "";
                    $scope.apellidosIn = "";
                    $scope.sexSelect = "";
                });
            });
        }

        $scope.showConsultaNotas = function(index){
            $("#myModalConsultaNotas-"+index).modal('show');
        }

    });


    app.controller('profesoresController', function($scope, $http){
        $scope.getProfesores = function(){
            $http.get('/getProfesores').then(function(data){
                $scope.profesores = data.data;
            });
        };
        $scope.getProfesores();
    });

    app.controller('asignaturasController', function($scope, $http){
        $scope.getAsignaturas = function(){
            $http.get('/getAsignaturas').then(function(data){
                $scope.asignaturas = data.data;
            });
        };
        $scope.getAsignaturas();


        $scope.toggleAsignacion = function(){
            if($scope.asignacion){
                $scope.asignacion = false;
            }else{
                $http.get('/getAlumnos').then(function(data){
                    $scope.asignacion = true;
                    $scope.alumnos = data.data;
                });
            }
        };

        $scope.asignarAlumno = function(){

            $http.post('/asignarAlumno', {idAlumno: $scope.alumnoSelect, idAsignatura: $scope.asigSelect} ).then(function(){
                $scope.$evalAsync(function(){
                    $scope.getAsignaturas();
                    $scope.asignacion = false;
                    $scope.alumnoSelect = null;
                    $scope.asigSelect = null;
                });
            });
        }
    });

    app.controller('actividadesController', function($scope, $http){
        $scope.getActividades = function(){
            $http.get('/getActividades').then(function(data){
                $scope.actividades = data.data;
            });
        };
        $scope.getActividades();
    });

    app.directive('modalConsulta', function(){
        return{
            restrict: 'E',
            scope: {
                alumno: '=',
                index: '='
            },
            templateUrl: '/modalConsulta.html',
            controller: function($scope, $http){
                 this.clean = function(){
                     $scope.notas = null;
                 };

                 $scope.getNotas = function(){
                     $http({
                        method: 'GET',
                        url: '/consultarNota',
                        params: {idAlumno: $scope.alumno.idAlumno, idAsignatura: $scope.asignaturaSel}
                    })
                     .then(function(data){
                         $scope.notas = data.data;
                     });
                 }

                 this.getAsignaturas = function(){
                     $http.get('/getAsignaturas').then(function(data){
                         $scope.asignaturas = data.data;
                     });
                 };
                 this.getAsignaturas();
             },
             controllerAs: "modal"
        };
    });


})();
