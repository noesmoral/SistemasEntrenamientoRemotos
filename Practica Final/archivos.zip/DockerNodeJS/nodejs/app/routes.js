// app/routes.js
var apiFunctions = require('../api/controllers/apiFunctions');
module.exports = function(app) {
	app.get('/', function(req, res) {
		res.render('index.ejs'); // load the index.ejs file
	});

	app.get('/getAlumnos', function(req, res){
		apiFunctions.getAlumnos(res);
	});

	app.get('/getProfesores', function(req, res){
		apiFunctions.getProfesores(res);
	});

	app.get('/getAsignaturas', function(req, res){
		apiFunctions.getAsignaturas(res);
	});

	app.get('/getActividades', function(req, res){
		apiFunctions.getActividades(res);
	});

	app.post('/createAlumno', function(req, res){
		apiFunctions.createAlumno(req.body.alumno, res);
	});

	app.post('/asignarAlumno', function(req, res){
		apiFunctions.asignarAlumno(req.body.idAlumno,req.body.idAsignatura, res);
	});

	app.post('/actualizarNota', function(req, res){
		apiFunctions.actualizarNota(req.body.idAlumno,req.body.idAsignatura, req.body.idActividad, req.body.nota, res);
	});

	app.get('/consultarNota', function(req, res){
		apiFunctions.consultarNota(req.query.idAlumno, req.query.idAsignatura, res);
	});

}
