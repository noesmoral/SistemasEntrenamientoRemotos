var pool = require('../../config/pool').pool;

module.exports = {
  getAlumnos: getAlumnos,
  getProfesores: getProfesores,
  getAsignaturas: getAsignaturas,
  getActividades: getActividades,
  createAlumno: createAlumno,
  asignarAlumno: asignarAlumno,
  actualizarNota: actualizarNota,
  consultarNota: consultarNota
};


function getAlumnos(callback) {
    // Obtiene la tabla alumno
    pool.getConnection(function(err,connection){
        connection.query("SELECT a.`idAlumno`, a.`Nombre`, a.`Apellidos`, a.`Sexo` FROM `Alumno` a",function(err,rows){
        if(err){
                throw err;
            }else{
                callback.json(rows);
            }
            connection.release();
        });
    });
}

function getProfesores(callback) {
    // Obtiene la tabla profesores
    pool.getConnection(function(err,connection){
        connection.query("SELECT p.`idProfesor`, p.`Nombre`, p.`Apellidos` FROM `Profesor` p",function(err,rows){
        if(err){
                throw err;
            }else{
                callback.json(rows);
            }
            connection.release();
        });
    });
}

function getAsignaturas(callback) {
    // Obtiene la tabla asignaturas
    pool.getConnection(function(err,connection){
        connection.query("SELECT a.`idAsignatura`, a.`NombreAsignatura` FROM `Asignatura` a",function(err,rows){
        if(err){
                throw err;
            }else{
                callback.json(rows);
            }
            connection.release();
        });
    });
}

function getActividades(callback) {
    // Obtiene la tabla actividades
    pool.getConnection(function(err,connection){
        connection.query("SELECT p.`idActividad`, p.`Nombre`, p.`Porcentaje` FROM `Actividad` p",function(err,rows){
        if(err){
                throw err;
            }else{
                callback.json(rows);
            }
            connection.release();
        });
    });
}

function createAlumno(alumno, callback) {
      // Crea un nuevo alumno
      console.log(alumno)
      pool.getConnection(function(err,connection){
          connection.query("INSERT INTO `Alumno` SET ?", alumno, function(err,rows){
          if(err){
            throw err;
          }else{
            callback.json({STATUS: 200, SUCCESS: "Alumno creado correctamente"});
          }
            connection.release();
          });
      });
}

function asignarAlumno(idAlumno, idAsignatura, callback) {
      // Crea un nueva asignacion alumno-asignatura
      //console.log(alumno)
      pool.getConnection(function(err,connection){
          connection.query("INSERT INTO `ActiAlumAsig` SET ?", {idActi:1 ,idAlum:idAlumno, Nota:0.0, idAsig: idAsignatura}, function(err,rows){
            if(err){
              throw err;
            }else{
              connection.query("INSERT INTO `ActiAlumAsig` SET ?", {idActi:2 ,idAlum: idAlumno, Nota:0.0, idAsig: idAsignatura}, function(err,rows){
                if(err){
                  throw err;
                }else{
                  callback.json({STATUS: 200, SUCCESS: "Alumno asignado correctamente"});
                }
              });
            }
            connection.release();
          });
      });
 }

function actualizarNota(idAlumno, idAsignatura, idActividad, nota, callback) {
      // Modifica la nota de una actividad de un alumno
      //console.log(alumno)
      pool.getConnection(function(err,connection){
          connection.query("UPDATE `ActiAlumAsig` SET ?", {idActi: idActividad ,idAlum: idAlumno, Nota: nota, idAsig: idAsignatura}, function(err,rows){
            if(err){
              throw err;
            }else{
              callback.json({STATUS: 200, SUCCESS: "Nota modificada correctamente"});
            }
            connection.release();
          });
      });
}

function consultarNota(idAlumno, idAsignatura, callback) {
      // Modifica la nota de una actividad de un alumno
      //console.log(alumno)
      pool.getConnection(function(err,connection){
        connection.query("SELECT p.`idAlum`, p.`idActi`, p.`Nota`  as Nota FROM `ActiAlumAsig` p WHERE p.`idAlum`="+idAlumno+" AND p.`idAsig`="+idAsignatura,function(err,rows){
            if(err){
              throw err;
            }else{
              callback.json(rows);
            }
            connection.release();
          });
      });
}
